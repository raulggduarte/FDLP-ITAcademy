import { Treballador } from "./Treballador.js";

export function createWorker() {
    const worker = new Treballador (`Eustaquio`, `Ramírez`, `Jefazo`, true);
    return worker;
}