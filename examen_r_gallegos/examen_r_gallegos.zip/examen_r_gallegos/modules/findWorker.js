import { treballadors } from "./dades.js";

export function findWorker() {
    const personIndex = treballadors.findIndex(element => element.nom === 'Pep' && element.cognom === 'Vila');
    return treballadors[personIndex];
}