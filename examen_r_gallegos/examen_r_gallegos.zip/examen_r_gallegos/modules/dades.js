export const treballadors = [
   {
      nom : "Ana",
      cognom: "Puig",
      carrec: "venedor(a)",
      disponibilitatTrasllat : true
   },
   {
      nom : "Lluis",
      cognom: "Soto",
      carrec: "venedor(a)",
      disponibilitatTrasllat : false
   },
   {
      nom : "Cristina",
      cognom: "Tomas",
      carrec: "administratiu(a)",
      disponibilitatTrasllat : false
   },
   {
      nom : "Andreu",
      cognom: "Ricart",
      carrec: "venedor(a)",
      disponibilitatTrasllat : true
   },
   {
      nom : "Pep",
      cognom: "Vila",
      carrec: "venedor(a)",
      disponibilitatTrasllat : false
   },
   {
      nom : "Núria",
      cognom: "Roure",
      carrec: "administratiu(a)",
      disponibilitatTrasllat : true
   },

]

