export const array1 = [];
export const array2 = [];