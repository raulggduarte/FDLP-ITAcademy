import { array1, array2 } from "./variables.js";

export function showArrays (){
    document.querySelector("#array1").innerHTML = array1.join(",");
    document.querySelector("#array2").innerHTML = array2.join(",");
}