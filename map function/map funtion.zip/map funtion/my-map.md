{\rtf1\ansi\ansicpg1252\cocoartf2580
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 ### My-map\
\
This program aims to be a function prepared to receive an array and another function as parameters. \
\
The program should be able to apply to each element of the array the function passed as the second parameter and return a new array with this result. \
\
Case 1:\
The first parameter should be an array\
\
As a user, when I pass not an array as first parameter to the program, we see an error in the console that says 'first parameter is not an array'.\
\
Case 2:\
The second parameter should be a function\
\
As a user, when I pass not a function as second parameter to the program, we see an error in the console that says 'second parameter is not a function'.\
\
Case 3:\
Sum by one\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers sumed by one.\
\
Case 4:\
Sum by two\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers sumed by two.\
\
\
Case 5:\
Sum by three\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers sumed by three.\
\
Case 6:\
Multiply by two\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers multiplied by two.\
\
Case 7:\
Rest by two\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers rested by two.\
\
Case 8:\
Divide by two\
\
As a user, when I pass an array with numbers and call to the program, we get a new array with all numbers divided by two.\
\
Case 9:\
Convert to upper case\
\
As a user, when I pass an array with strings in lower case and call to the program, we get a new array with all words to upper case.\
\
\
AXES\
\
1\
- How create array\
- How interact user\
\
2\
- Apply something for each element\
\
}