
function askForWords(numberOfWords, arrayOfWords) {
    for ( let i = 0 ; i < numberOfWords ; i++ ) {
        arrayOfWords[i] = prompt(`Escriu la paraula número ${i + 1}`)
    }
}

function insertAnswer (numberOfWords, arrayOfWords) {
    document.getElementById("numeroParaules").innerHTML = numberOfWords
    document.getElementById("llistaParaules").innerHTML = arrayOfWords
}

function showResponse() {
    document.getElementById("resposta").style.display = "block"
    document.getElementById("llistaParaules").style.display = "block"
    document.getElementById("botoEsborra").style.display = "block"
}

function esborrar() {
    document.getElementById("wordsNumber").value = ""
    document.getElementById("resposta").style.display = "none"
    document.getElementById("llistaParaules").style.display = "none"
    document.getElementById("botoEsborra").style.display = "none"
}

function insertWords() {

    let numberOfWords = parseInt(document.getElementById("wordsNumber").value)
    let arrayOfWords = new Array(numberOfWords);

    askForWords(numberOfWords, arrayOfWords)

    insertAnswer(numberOfWords, arrayOfWords)

    showResponse()
}