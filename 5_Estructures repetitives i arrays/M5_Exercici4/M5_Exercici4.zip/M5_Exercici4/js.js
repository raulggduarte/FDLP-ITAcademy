/*Has de modificar el programa anterior per afegir una nova funcionalitat:
establir un número màxim de 5 intents.
Si l’usuari encerta el número escollit pel programa abans d'aquests 5 intents,
el programa mostra el següent missatge per pantalla:
“Enhorabona, el número és X i has necessitat Y intents per encertar-lo”.
Si no encerta el número abans de 5 intents, el programa mostra per pentalla: 
"Has utilitzat massa intents! El número és X "*/

function chooseProgramNumber() {
    return Math.ceil((Math.random() * 10))
}

function playTheGame(programNumber) {
    let userNumber
    let attempts = 0

    do {
            userNumber = Number(prompt("Endevina el nombre de l'1 al 10 que estic pensant:", ""));
            if (!checkCorrectNumber(userNumber)) errorMessage();
            attempts += 1
            console.log(attempts)
    } while (userNumber != programNumber && attempts < 5);
    
    (userNumber == programNumber && attempts <= 5) ? winnerAnswer(programNumber) : maxAttempsMessage(programNumber)
}

function checkCorrectNumber(userNumber) {
    return Number.isInteger(userNumber) && 1 <= userNumber && userNumber <= 10
}

function errorMessage() {
    alert(`Estic pensant un nombre de l'1 al 10!!`)
}

function winnerAnswer(winnerNumber) {
    document.getElementById("answer").innerHTML = `Enhorabona, el número és ${winnerNumber}!`
    document.getElementById("deleteButton").style.display = "block"
}

function maxAttempsMessage(programNumber){
    document.getElementById("answer").innerHTML = `Has utilitzat massa intents! El número és ${programNumber}!`
    document.getElementById("deleteButton").style.display = "block"
}

function showResponse() {
    document.getElementById("answer").style.display = "block"
    document.getElementById("playButton").style.display = "none"
}

function deleteData() {
    document.getElementById("answer").style.display = "none"
    document.getElementById("deleteButton").style.display = "none"
    document.getElementById("playButton").style.display = "block"
}

function playTheGameMAIN() {
    let programNumber = chooseProgramNumber()
    console.log(programNumber)

    playTheGame(programNumber)

    showResponse()
}