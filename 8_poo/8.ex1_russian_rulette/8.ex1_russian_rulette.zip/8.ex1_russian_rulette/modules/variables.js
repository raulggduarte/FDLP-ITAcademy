export const REVOLVER_HOLES = 6;
export const NUMBER_OF_BULLETS = 1;
export const PLAYERS = [];