export function restartGame() {
    location.reload();
}