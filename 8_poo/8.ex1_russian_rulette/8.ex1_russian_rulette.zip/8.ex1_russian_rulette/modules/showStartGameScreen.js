export function showStartGameScreen () {
    document.querySelector("#registerScreen").style.display = "none";
    document.querySelector("#startGameScreen").style.display = "block";
}