export function showFinishScreen() {
    document.querySelector("#startGameScreen").style.display = "none";
    document.querySelector("#endGameScreen").style.display = "block";
}