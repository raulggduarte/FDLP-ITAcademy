import { HOTELS } from "./variables.js";

export function deleteHotel (i) {
    if (i === null) return;
    const index = HOTELS.indexOf(HOTELS[i]);
    alert(`L'hotel ${HOTELS[i].Name} ha estat eliminat.`)
    HOTELS.splice(index,1);
    document.querySelector("#registersAmount").innerHTML = HOTELS.length;
}