export function errorMessage() {
    alert("No és una entrada vàlida.");
  }