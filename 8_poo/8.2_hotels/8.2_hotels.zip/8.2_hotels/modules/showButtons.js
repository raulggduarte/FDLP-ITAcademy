export function showButtons() {
  document.querySelector("#deleteHotelButton").style.display = "block";
  document.querySelector("#showHotelButton").style.display = "block";
  document.querySelector("#modifyHotel").style.display = "block";
  document.querySelector("#registersAmountText").style.display = "block";
}
