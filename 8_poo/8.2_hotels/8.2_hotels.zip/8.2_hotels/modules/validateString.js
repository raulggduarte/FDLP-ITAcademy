import { errorMessage } from "./errorMessage.js";

export function validateString (string) {
    if ( !isNaN(string) || string < 3 ) {
        errorMessage();
        return false;
    } else {
    return true;
}
}