import { createHotel } from "./createHotel.js";
import { HOTELS } from "./variables.js";

export function registerHotel() {
  HOTELS.push(createHotel());
  console.log(HOTELS);
  document.querySelector("#registersAmount").innerHTML = HOTELS.length;
  document.querySelector("#registersAmountText").style.display = "block";
}
