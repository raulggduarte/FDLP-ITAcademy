import { Hotel } from "./Hotel.js";
import { askForName } from "./askForName.js";
import { askForRoomsQty } from "./askForRoomsQty.js";
import { askForFloorsQty } from "./askForFloorsQty.js";
import { askForTotalSurface } from "./askForTotalSurface.js";

export function createHotel() {
  const hotel = new Hotel(
    askForName(),
    askForRoomsQty(),
    askForFloorsQty(),
    askForTotalSurface(),
  );
  console.log(hotel)
  return hotel;
}
