import { validateString } from "./validateString.js";

export function askForName() {
    let name;
    do {
      name = prompt("Nome de l'hotel:");
    } while (validateString(name) !== true);
    return name;
}