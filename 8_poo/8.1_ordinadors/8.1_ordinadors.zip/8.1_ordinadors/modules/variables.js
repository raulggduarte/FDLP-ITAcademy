export const COMPUTERS = [];
export const ID_REGISTER = [];