export function showButtons() {
  document.querySelector("#enterSoftwareButton").style.display = "block";
  document.querySelector("#getInfoPC").style.display = "block";
  document.querySelector("#modifyPC").style.display = "block";
  document.querySelector("#deletePC").style.display = "block";
}
