export function getInfoPC (computer){
    alert(computer);
}