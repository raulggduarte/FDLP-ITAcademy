/*Aquest programa calcula l'edat mitjana d'un número de persones introduït per teclat.
S'ha de crear una funció que s'encarregui de demanar les edats a l'usuari i de calcular
l'edat mitjana.
La funció rebrà per paràmetre el nº de persones a qui ha de demanar l'edat.
L'edat de les persones només serà vàlida si està compresa entre 0 i 120 anys.
La mitjana de les edats introduïdes s'ha de retornar per la funció (return).*/

window.onload = startFunction();

const array = [2,3,1,5,4];

const indexSmaller = workWithArray(array)

document.getElementById("answer1").innerHTML = `El número més petit està a la posició ${indexSmaller}.`;
document.getElementById("answer1").style.display = "block";

const num1 = 3;
const num2 = 10;
const newArray = createArray (num1, num2);

document.getElementById("answer2").innerHTML = `Els números compresos entre ${num1} i ${num2} són ${newArray}.`;
document.getElementById("answer2").style.display = "block";


function createArray(num1, num2){
  arrayLength = num2 - num1;
  numArray = [];
  for (let i = 0 ; i < arrayLength-1 ; i++ ) {
    num1 ++;
    numArray.push(num1);
  }
  return numArray;
}

function startFunction(){
  console.log("sóc una funció");
}


function workWithArray(array) {
  console.log(`El número més gran és ${Math.max(...array)}`);

  return array.indexOf(Math.min(...array));
}
